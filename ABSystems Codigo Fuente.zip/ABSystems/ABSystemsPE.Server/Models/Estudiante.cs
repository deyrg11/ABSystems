using System.ComponentModel.DataAnnotations;

namespace ABSystemsPE.Server.Models
{
    public class Estudiante
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "El nombre es obligatorio.")]
        public string Nombres { get; set; } = string.Empty;

        [Required(ErrorMessage = "El apellido es obligatorio.")]
        public string Apellidos { get; set; } = string.Empty;

        [Required(ErrorMessage = "La fecha de nacimiento es obligatoria.")]
        public DateTime FechaNacimiento { get; set; } = DateTime.Now;

        [Required(ErrorMessage = "La dirección es obligatoria.")]
        public string Direccion { get; set; } = string.Empty;

        [Required(ErrorMessage = "El sexo es obligatorio.")]
        public string Sexo { get; set; } = string.Empty;

        [Required(ErrorMessage = "El CURP es obligatorio.")]
        [RegularExpression(@"^[A-Z]{1}[AEIOU]{1}[A-Z]{2}[0-9]{2}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])[HM]{1}(AS|BC|BS|CC|CS|CH|CL|CM|DF|DG|GT|GR|HG|JC|MC|MN|MS|NT|NL|OC|PL|QT|QR|SP|SL|SR|TC|TS|TL|VZ|YN|ZS){1}[B-DF-HJ-NP-TV-Z]{3}[0-9A-Z]{1}[0-9]{1}$", ErrorMessage = "Formato de CURP no válido.")]
        public string CURP { get; set; } = string.Empty;

        [Required(ErrorMessage = "El teléfono es obligatorio.")]
        [Phone(ErrorMessage = "Formato de teléfono no válido.")]
        public string Telefono { get; set; } = string.Empty;

        [Required(ErrorMessage = "El email es obligatorio.")]
        [EmailAddress(ErrorMessage = "Formato de email no válido.")]
        public string Email { get; set; } = string.Empty;

        [Required(ErrorMessage = "La carrera es obligatoria.")]
        public string Carrera { get; set; } = string.Empty;

        [Required(ErrorMessage = "La modalidad es obligatoria.")]
        public string Modalidad { get; set; } = string.Empty;

        public bool EsBecado { get; set; }

        // Opcionales
        public string? DescripcionPersonal { get; set; }
        public bool TieneMascotas { get; set; }
        public string? Mascotas { get; set; }
        public string? HorarioComida { get; set; }
    }
} 