using Microsoft.EntityFrameworkCore;
using ABSystemsPE.Server.Data;
using ABSystemsPE.Server.Services;
using ABSystemsPE.Server.Models;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddDbContext<AppDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));
builder.Services.AddScoped<EstudianteService>();

// Agregar CORS
builder.Services.AddCors(options =>
{
    options.AddPolicy("AllowAll", policy =>
    {
        policy.AllowAnyOrigin()
              .AllowAnyMethod()
              .AllowAnyHeader();
    });
});

builder.Services.AddControllers();

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
    app.UseWebAssemblyDebugging();
}

app.UseHttpsRedirection();

// Usar CORS
app.UseCors("AllowAll");

// ==================== SERVIR ARCHIVOS ESTÁTICOS DEL CLIENTE BLAZOR ====================
// Habilita el soporte para archivos de Blazor WebAssembly (incluye archivos comprimidos)
app.UseBlazorFrameworkFiles();
// Habilita la búsqueda automática de archivos predeterminados como index.html
app.UseDefaultFiles();
// Permite servir archivos estáticos (JS, CSS, imágenes, etc.) desde wwwroot
app.UseStaticFiles();

app.UseRouting();

// Mapear los controladores para manejar las rutas de la API (por ejemplo, /api/estudiantes)
app.MapControllers();

// ==================== FALLBACK PARA APLICACIÓN BLAZOR ====================
// Redirige cualquier ruta no encontrada a index.html (necesario para aplicaciones SPA como Blazor)
app.MapFallbackToFile("index.html");

app.Run();

