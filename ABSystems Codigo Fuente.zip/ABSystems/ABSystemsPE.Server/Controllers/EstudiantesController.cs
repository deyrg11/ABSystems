// Importación de espacios de nombres necesarios
using Microsoft.AspNetCore.Mvc;
using ABSystemsPE.Server.Models;
using ABSystemsPE.Server.Services;
using System.Collections.Generic;
using System.Threading.Tasks;
using Microsoft.Extensions.Logging;

namespace ABSystemsPE.Server.Controllers
{
    // Marca esta clase como controlador de API
    [ApiController]
    // Define la ruta base para este controlador: api/estudiantes
    [Route("api/[controller]")]
    public class EstudiantesController : ControllerBase
    {
        // Servicio que maneja la lógica relacionada con estudiantes
        private readonly EstudianteService _estudianteService;
        // Servicio para registrar logs
        private readonly ILogger<EstudiantesController> _logger;

        // Constructor con inyección de dependencias
        public EstudiantesController(EstudianteService estudianteService, ILogger<EstudiantesController> logger)
        {
            _estudianteService = estudianteService;
            _logger = logger;
        }

        // Método GET para listar estudiantes con paginación, filtros y ordenamiento
        [HttpGet]
        public async Task<ActionResult<PagedResult<Estudiante>>> GetEstudiantes(
            [FromQuery] int pagina = 1, // Página actual
            [FromQuery] int tamañoPagina = 20, // Cantidad por página
            [FromQuery] string? searchQuery = null, // Búsqueda por texto
            [FromQuery] string? carrera = null, // Filtro por carrera
            [FromQuery] string? sexo = null, // Filtro por sexo
            [FromQuery] DateTime? fechaNacimiento = null, // Filtro por fecha de nacimiento
            [FromQuery] string sortBy = "apellidos", // Campo de ordenamiento
            [FromQuery] string sortOrder = "asc") // Orden ascendente o descendente
        {
            _logger.LogInformation("GetEstudiantes llamado con página: {Pagina}, tamaño: {TamañoPagina}", pagina, tamañoPagina);

            try
            {
                // Obtener estudiantes filtrados y paginados
                var estudiantes = await _estudianteService.ObtenerEstudiantesAsync(
                    pagina, tamañoPagina, searchQuery, carrera, sexo, fechaNacimiento, sortBy, sortOrder);

                // Obtener la cantidad total de estudiantes con los mismos filtros
                var totalEstudiantes = await _estudianteService.ContarEstudiantesAsync(searchQuery, carrera, sexo, fechaNacimiento);

                // Calcular total de páginas
                var totalPages = (int)System.Math.Ceiling(totalEstudiantes / (double)tamañoPagina);

                // Preparar respuesta paginada
                var result = new PagedResult<Estudiante>
                {
                    Items = estudiantes,
                    TotalPages = totalPages,
                    CurrentPage = pagina,
                    TotalItems = totalEstudiantes,
                    PageSize = tamañoPagina
                };

                _logger.LogInformation("Devolviendo {Count} estudiantes de {Total} totales", estudiantes.Count, totalEstudiantes);
                return result;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error en GetEstudiantes");
                return StatusCode(500, "Error interno del servidor");
            }
        }

        // Obtener un estudiante por su ID
        [HttpGet("{id}")]
        public async Task<ActionResult<Estudiante>> GetEstudiante(int id)
        {
            _logger.LogInformation("GetEstudiante llamado con ID: {Id}", id);

            var estudiante = await _estudianteService.ObtenerPorIdAsync(id);
            if (estudiante == null)
            {
                return NotFound(); // Retorna 404 si no se encuentra
            }
            return estudiante; // Retorna el estudiante si existe
        }

        // Crear un nuevo estudiante
        [HttpPost]
        public async Task<ActionResult<Estudiante>> PostEstudiante(Estudiante estudiante)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Si el modelo no es válido, retorna 400
            }

            var nuevoEstudiante = await _estudianteService.AgregarAsync(estudiante);
            // Retorna 201 Created con la ubicación del nuevo recurso
            return CreatedAtAction(nameof(GetEstudiante), new { id = nuevoEstudiante.Id }, nuevoEstudiante);
        }

        // Actualizar un estudiante existente
        [HttpPut("{id}")]
        public async Task<IActionResult> PutEstudiante(int id, Estudiante estudiante)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState); // Modelo inválido
            }

            if (id != estudiante.Id)
            {
                return BadRequest(); // El ID en la URL no coincide con el del objeto
            }

            var success = await _estudianteService.ActualizarAsync(id, estudiante);
            if (!success)
            {
                return NotFound(); // No se encontró para actualizar
            }

            return NoContent(); // Retorna 204 No Content si se actualizó correctamente
        }

        // Eliminar un estudiante por ID
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteEstudiante(int id)
        {
            var success = await _estudianteService.EliminarAsync(id);
            if (!success)
            {
                return NotFound(); // No se encontró el recurso
            }
            return NoContent(); // Eliminado exitosamente
        }
    }
}
