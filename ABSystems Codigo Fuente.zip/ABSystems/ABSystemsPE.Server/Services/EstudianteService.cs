using Microsoft.EntityFrameworkCore;
using ABSystemsPE.Server.Models;
using ABSystemsPE.Server.Data;
using System;
using System.Threading.Tasks;

namespace ABSystemsPE.Server.Services
{
    public class EstudianteService
    {
        private readonly AppDbContext _context;

        public EstudianteService(AppDbContext context)
        {
            _context = context;
        }

        public async Task<List<Estudiante>> ObtenerEstudiantesAsync(int pagina, int tamañoPagina, string? searchQuery, string? carrera, string? sexo, DateTime? fechaNacimiento, string sortBy, string sortOrder)
        {
            var query = _context.Estudiantes.AsQueryable();

            // Lógica de búsqueda y filtros
            if (!string.IsNullOrEmpty(searchQuery))
            {
                query = query.Where(e => e.Nombres.Contains(searchQuery) || e.Apellidos.Contains(searchQuery) || e.CURP.Contains(searchQuery));
            }
            if (!string.IsNullOrEmpty(carrera))
            {
                query = query.Where(e => e.Carrera == carrera);
            }
            if (!string.IsNullOrEmpty(sexo))
            {
                query = query.Where(e => e.Sexo == sexo);
            }
            if (fechaNacimiento.HasValue)
            {
                query = query.Where(e => e.FechaNacimiento.Date == fechaNacimiento.Value.Date);
            }

            // Lógica de ordenamiento
            query = sortOrder.ToLower() == "asc"
                ? query.OrderBy(e => e.Apellidos).ThenBy(e => e.Nombres)
                : query.OrderByDescending(e => e.Apellidos).ThenByDescending(e => e.Nombres);

            return await query
                .Skip((pagina - 1) * tamañoPagina)
                .Take(tamañoPagina)
                .ToListAsync();
        }

        public async Task<int> ContarEstudiantesAsync(string? searchQuery, string? carrera, string? sexo, DateTime? fechaNacimiento)
        {
            var query = _context.Estudiantes.AsQueryable();

            // Aplicar los mismos filtros para un conteo preciso
            if (!string.IsNullOrEmpty(searchQuery))
            {
                query = query.Where(e => e.Nombres.Contains(searchQuery) || e.Apellidos.Contains(searchQuery) || e.CURP.Contains(searchQuery));
            }
            if (!string.IsNullOrEmpty(carrera))
            {
                query = query.Where(e => e.Carrera == carrera);
            }
            if (!string.IsNullOrEmpty(sexo))
            {
                query = query.Where(e => e.Sexo == sexo);
            }
            if (fechaNacimiento.HasValue)
            {
                query = query.Where(e => e.FechaNacimiento.Date == fechaNacimiento.Value.Date);
            }

            return await query.CountAsync();
        }

        public async Task<Estudiante?> ObtenerPorIdAsync(int id)
        {
            return await _context.Estudiantes.FindAsync(id);
        }

        public async Task<Estudiante> AgregarAsync(Estudiante estudiante)
        {
            _context.Estudiantes.Add(estudiante);
            await _context.SaveChangesAsync();
            return estudiante;
        }

        public async Task<bool> ActualizarAsync(int id, Estudiante estudiante)
        {
            var estudianteExistente = await _context.Estudiantes.FindAsync(id);
            if (estudianteExistente == null)
                return false;

            estudianteExistente.Nombres = estudiante.Nombres;
            estudianteExistente.Apellidos = estudiante.Apellidos;
            estudianteExistente.FechaNacimiento = estudiante.FechaNacimiento;
            estudianteExistente.Direccion = estudiante.Direccion;
            estudianteExistente.Sexo = estudiante.Sexo;
            estudianteExistente.CURP = estudiante.CURP;
            estudianteExistente.Telefono = estudiante.Telefono;
            estudianteExistente.Email = estudiante.Email;
            estudianteExistente.Carrera = estudiante.Carrera;
            estudianteExistente.Modalidad = estudiante.Modalidad;
            estudianteExistente.EsBecado = estudiante.EsBecado;
            estudianteExistente.DescripcionPersonal = estudiante.DescripcionPersonal;
            estudianteExistente.TieneMascotas = estudiante.TieneMascotas;
            estudianteExistente.Mascotas = estudiante.Mascotas;
            estudianteExistente.HorarioComida = estudiante.HorarioComida;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> EliminarAsync(int id)
        {
            var estudiante = await _context.Estudiantes.FindAsync(id);
            if (estudiante == null)
                return false;

            _context.Estudiantes.Remove(estudiante);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
