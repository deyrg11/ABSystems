using Microsoft.AspNetCore.Components.Web;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;
using ABSystemsPE;
using ABSystemsPE.Services;

// ========================================
// CONFIGURACIÓN DE LA APLICACIÓN BLAZOR
// ========================================

var builder = WebAssemblyHostBuilder.CreateDefault(args);

// Configurar componentes raíz
builder.RootComponents.Add<App>("#app");
builder.RootComponents.Add<HeadOutlet>("head::after");

// ========================================
// CONFIGURACIÓN DE SERVICIOS
// ========================================

// Configurar HttpClient para comunicación con la API
// Se utiliza la dirección base del host para que la API se consuma desde el mismo puerto donde se sirve la aplicación.
builder.Services.AddScoped(sp => new HttpClient { BaseAddress = new Uri(builder.HostEnvironment.BaseAddress) });

// Registrar servicios de la aplicación
builder.Services.AddScoped<EstudianteService>();

// ========================================
// INICIALIZACIÓN DE LA APLICACIÓN
// ========================================

await builder.Build().RunAsync();

