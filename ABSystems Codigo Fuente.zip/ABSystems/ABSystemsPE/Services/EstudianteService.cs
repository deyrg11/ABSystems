using System.Net.Http;
using System.Net.Http.Json;
using System.Threading.Tasks;
using ABSystemsPE.Models;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Net;

namespace ABSystemsPE.Services
{
    /// <summary>
    /// Servicio para gestionar las operaciones CRUD de estudiantes
    /// </summary>
    public class EstudianteService
    {
        private readonly HttpClient _httpClient;
        private const string BaseUrl = "api/estudiantes";

        public EstudianteService(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }

        // ========================================
        // MÉTODOS DE CONSULTA
        // ========================================

        /// <summary>
        /// Obtiene una lista paginada de estudiantes con filtros y ordenamiento
        /// </summary>
        public async Task<PagedResult<Estudiante>?> ObtenerEstudiantesAsync(
            int pagina, 
            int tamañoPagina, 
            string? searchQuery, 
            string? carrera, 
            string? sexo, 
            DateTime? fechaNacimiento, 
            string sortBy, 
            string sortOrder)
        {
            var queryParams = ConstruirQueryParams(
                pagina, 
                tamañoPagina, 
                searchQuery, 
                carrera, 
                sexo, 
                fechaNacimiento, 
                sortBy, 
                sortOrder);

            var url = $"{BaseUrl}?{queryParams}";
            return await _httpClient.GetFromJsonAsync<PagedResult<Estudiante>>(url);
        }

        /// <summary>
        /// Obtiene un estudiante por su ID
        /// </summary>
        public async Task<Estudiante?> ObtenerPorIdAsync(int id)
        {
            return await _httpClient.GetFromJsonAsync<Estudiante>($"{BaseUrl}/{id}");
        }

        // ========================================
        // MÉTODOS DE MODIFICACIÓN
        // ========================================

        /// <summary>
        /// Agrega un nuevo estudiante
        /// </summary>
        public async Task<Estudiante?> AgregarAsync(Estudiante estudiante)
        {
            var response = await _httpClient.PostAsJsonAsync(BaseUrl, estudiante);
            
            if (response.IsSuccessStatusCode)
            {
                return await response.Content.ReadFromJsonAsync<Estudiante>();
            }
            
            return null;
        }

        /// <summary>
        /// Actualiza un estudiante existente
        /// </summary>
        public async Task<bool> ActualizarAsync(int id, Estudiante estudiante)
        {
            var response = await _httpClient.PutAsJsonAsync($"{BaseUrl}/{id}", estudiante);
            return response.IsSuccessStatusCode;
        }

        /// <summary>
        /// Elimina un estudiante por su ID
        /// </summary>
        public async Task<bool> EliminarAsync(int id)
        {
            var response = await _httpClient.DeleteAsync($"{BaseUrl}/{id}");
            return response.IsSuccessStatusCode;
        }

        // ========================================
        // MÉTODOS PRIVADOS AUXILIARES
        // ========================================

        /// <summary>
        /// Construye los parámetros de consulta para la API
        /// </summary>
        private static string ConstruirQueryParams(
            int pagina, 
            int tamañoPagina, 
            string? searchQuery, 
            string? carrera, 
            string? sexo, 
            DateTime? fechaNacimiento, 
            string sortBy, 
            string sortOrder)
        {
            var query = new NameValueCollection
            {
                ["pagina"] = pagina.ToString(),
                ["tamañoPagina"] = tamañoPagina.ToString(),
                ["sortBy"] = sortBy,
                ["sortOrder"] = sortOrder
            };

            // Agregar filtros opcionales
            if (!string.IsNullOrEmpty(searchQuery))
            {
                query["searchQuery"] = searchQuery;
            }
            
            if (!string.IsNullOrEmpty(carrera))
            {
                query["carrera"] = carrera;
            }
            
            if (!string.IsNullOrEmpty(sexo))
            {
                query["sexo"] = sexo;
            }
            
            if (fechaNacimiento.HasValue)
            {
                query["fechaNacimiento"] = fechaNacimiento.Value.ToString("yyyy-MM-dd");
            }

            // Construir query string
            var queryPairs = query.AllKeys
                .Select(key => $"{WebUtility.UrlEncode(key)}={WebUtility.UrlEncode(query[key])}");
            
            return string.Join("&", queryPairs);
        }
    }
} 

