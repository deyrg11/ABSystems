using System.ComponentModel.DataAnnotations;

namespace ABSystemsPE.Models
{
    /// <summary>
    /// Modelo que representa un estudiante en el sistema
    /// </summary>
    public class Estudiante
    {
        // ========================================
        // PROPIEDADES DE IDENTIFICACIÓN
        // ========================================
        
        /// <summary>
        /// Identificador único del estudiante
        /// </summary>
        public int Id { get; set; }

        /// <summary>
        /// Nombres del estudiante
        /// </summary>
        [Required(ErrorMessage = "El nombre es obligatorio.")]
        [RegularExpression(@"^[a-zA-Z\u00C0-\u017F\s]+$", 
            ErrorMessage = "El nombre solo puede contener letras y espacios.")]
        public string Nombres { get; set; } = string.Empty;

        /// <summary>
        /// Apellidos del estudiante
        /// </summary>
        [Required(ErrorMessage = "El apellido es obligatorio.")]
        [RegularExpression(@"^[a-zA-Z\u00C0-\u017F\s]+$", 
            ErrorMessage = "El apellido solo puede contener letras y espacios.")]
        public string Apellidos { get; set; } = string.Empty;

        /// <summary>
        /// Clave Única de Registro de Población
        /// </summary>
        [Required(ErrorMessage = "El CURP es obligatorio.")]
        [RegularExpression(@"^[A-Z]{1}[AEIOU]{1}[A-Z]{2}[0-9]{2}(0[1-9]|1[0-2])(0[1-9]|[12][0-9]|3[01])[HM]{1}(AS|BC|BS|CC|CS|CH|CL|CM|DF|DG|GT|GR|HG|JC|MC|MN|MS|NT|NL|OC|PL|QT|QR|SP|SL|SR|TC|TS|TL|VZ|YN|ZS){1}[B-DF-HJ-NP-TV-Z]{3}[0-9A-Z]{1}[0-9]{1}$", 
            ErrorMessage = "Formato de CURP no válido.")]
        public string CURP { get; set; } = string.Empty;

        // ========================================
        // PROPIEDADES PERSONALES
        // ========================================
        
        /// <summary>
        /// Fecha de nacimiento del estudiante
        /// </summary>
        [Required(ErrorMessage = "La fecha de nacimiento es obligatoria.")]
        public DateTime FechaNacimiento { get; set; } = DateTime.Now;

        /// <summary>
        /// Sexo del estudiante (Hombre/Mujer)
        /// </summary>
        [Required(ErrorMessage = "El sexo es obligatorio.")]
        public string Sexo { get; set; } = string.Empty;

        /// <summary>
        /// Dirección de residencia del estudiante
        /// </summary>
        [Required(ErrorMessage = "La dirección es obligatoria.")]
        public string Direccion { get; set; } = string.Empty;

        // ========================================
        // PROPIEDADES DE CONTACTO
        // ========================================
        
        /// <summary>
        /// Número de teléfono del estudiante
        /// </summary>
        [Required(ErrorMessage = "El teléfono es obligatorio.")]
        [RegularExpression(@"^\d{10}$", 
            ErrorMessage = "El teléfono debe contener exactamente 10 dígitos numéricos.")]
        public string Telefono { get; set; } = string.Empty;

        /// <summary>
        /// Dirección de correo electrónico del estudiante
        /// </summary>
        [Required(ErrorMessage = "El email es obligatorio.")]
        [EmailAddress(ErrorMessage = "Formato de email no válido.")]
        public string Email { get; set; } = string.Empty;

        // ========================================
        // PROPIEDADES ACADÉMICAS
        // ========================================
        
        /// <summary>
        /// Carrera que estudia el estudiante
        /// </summary>
        [Required(ErrorMessage = "La carrera es obligatoria.")]
        public string Carrera { get; set; } = string.Empty;

        /// <summary>
        /// Modalidad de estudio (Presencial/Online/Ambos)
        /// </summary>
        [Required(ErrorMessage = "La modalidad es obligatoria.")]
        public string Modalidad { get; set; } = string.Empty;

        /// <summary>
        /// Indica si el estudiante tiene beca
        /// </summary>
        public bool EsBecado { get; set; }

        // ========================================
        // PROPIEDADES ADICIONALES (OPCIONALES)
        // ========================================
        
        /// <summary>
        /// Descripción personal del estudiante
        /// </summary>
        public string? DescripcionPersonal { get; set; }

        /// <summary>
        /// Indica si el estudiante tiene mascotas
        /// </summary>
        public bool TieneMascotas { get; set; }

        /// <summary>
        /// Descripción de las mascotas del estudiante
        /// </summary>
        public string? Mascotas { get; set; }

        /// <summary>
        /// Horario de comida preferido del estudiante
        /// </summary>
        public string? HorarioComida { get; set; }
    }
} 