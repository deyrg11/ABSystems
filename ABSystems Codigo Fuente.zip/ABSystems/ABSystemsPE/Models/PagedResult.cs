using System.Collections.Generic;

namespace ABSystemsPE.Models
{
    /// <summary>
    /// Modelo genérico para resultados paginados
    /// </summary>
    /// <typeparam name="T">Tipo de elementos en la lista</typeparam>
    public class PagedResult<T>
    {
        /// <summary>
        /// Lista de elementos de la página actual
        /// </summary>
        public List<T> Items { get; set; } = new();

        /// <summary>
        /// Número total de páginas
        /// </summary>
        public int TotalPages { get; set; }

        /// <summary>
        /// Número de la página actual
        /// </summary>
        public int CurrentPage { get; set; }

        /// <summary>
        /// Número total de elementos
        /// </summary>
        public int TotalItems { get; set; }

        /// <summary>
        /// Tamaño de cada página
        /// </summary>
        public int PageSize { get; set; }

        /// <summary>
        /// Indica si existe una página anterior
        /// </summary>
        public bool HasPreviousPage => CurrentPage > 1;

        /// <summary>
        /// Indica si existe una página siguiente
        /// </summary>
        public bool HasNextPage => CurrentPage < TotalPages;
    }
} 